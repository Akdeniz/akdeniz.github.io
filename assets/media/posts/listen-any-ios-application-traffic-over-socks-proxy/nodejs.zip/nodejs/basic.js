var libpath = require("path"),
    http = require("http"),
    fs = require("fs"),
    url = require("url");

var path = ".";
var port = 8080;

http.createServer(function (request, response) {

    var uri = url.parse(request.url).pathname;
    var filename = libpath.join(path, uri);

    libpath.exists(filename, function (exists) {
        if (!exists || fs.statSync(filename).isDirectory()) {
			console.log("not found!");
            response.writeHead(404, { "Content-Type": "text/plain" });
            response.write("404 Not Found\n");
            response.end();
            return;
        }

        fs.readFile(filename, "binary", function (err, file) {
            if (err) {
				console.log("file can not be readed : "+ filename);
                response.writeHead(500, {
                    "Content-Type": "text/plain"
                });
                response.write(err + "\n");
                response.end();
                return;
            }

			console.log("file is sended : "+ filename);
            response.writeHead(200, { "Content-Type": "application/octet-stream" });
            response.write(file, "binary");
            response.end();
        });
    });
}).listen(port);
console.log("Listening port " + port);